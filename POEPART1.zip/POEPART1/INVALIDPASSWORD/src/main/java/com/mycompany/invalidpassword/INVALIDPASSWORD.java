Password: password
Message: "Password is not correctly formatted..."
