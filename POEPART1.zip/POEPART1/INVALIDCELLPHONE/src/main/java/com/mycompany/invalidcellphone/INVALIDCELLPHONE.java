/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.invalidcellphone;

/**
 *
 * @author Student
 */
public class INVALIDCELLPHONE {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
