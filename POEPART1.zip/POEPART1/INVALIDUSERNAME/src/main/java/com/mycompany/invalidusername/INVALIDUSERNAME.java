Username: kyle!!!!!!!
Message: "Username is not correctly formatted..."
