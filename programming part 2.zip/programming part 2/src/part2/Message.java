/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part2;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Message {
     ArrayList<String> messagesIds = new ArrayList<>();
    ArrayList<String> recipientNumber = new ArrayList<>();
    ArrayList<String> messages = new ArrayList<>();
    ArrayList<String> msgHash = new ArrayList<>();
    ArrayList<String> messageStatus = new ArrayList<>();
    ArrayList<String> storedMessages = new ArrayList<>();

    Scanner input = new Scanner(System.in);
    Random random = new Random();

    int numMessageSent = 0;

    public void sendingMessage() {

        System.out.println("How many messages do you want to send?");
        int numberOfMessages = input.nextInt();
        input.nextLine();

        for (int i = 1; i <= numberOfMessages; i++) {

            System.out.println("MESSAGE: " + i);

            String messageID = generateMessage();

            System.out.println("Enter recipient cell number!!");
            String recipient = input.nextLine();

            String recipientResult = checkRecipientCell(recipient);

            if (recipientResult.equals("Valid number")) {
                recipientNumber.add(recipient);
            } else {
                System.out.println(recipientResult);
                i--;
                continue;
            }

            recipientNumber.add(recipient);

            System.out.println("Enter your message!!");
            String messageText = input.nextLine();

            if (messageText.length() > 250 || messageText.trim().isEmpty()) {

                System.out.println("Please enter a message of less than 250 characters.");
                i--;
                continue;

            }

            messages.add(messageText);

            String messageHash = createMessageHash(messageID,
                    messages.size(), messageText);

            msgHash.add(messageHash);

            String status = sentMessage(messageID, recipient, messageText, messageHash);

            messageStatus.add(status);
            if (status.equals("Sent")) {
                numMessageSent++;

            }

            System.out.println("\n====== Message details ======");
            System.out.println("Message ID: " + messageID);
            System.out.println("Recipient: " + recipient);
            System.out.println("Message: " + messageText);
            System.out.println("Message Hash: " + messageHash);

        }
        // printMessages();

        System.out.println("Total Messages sent: " + returnTotalMesssages());

        //for (int i = 0; i < messages.size(); i++) {
        //System.out.println("\n===== Messages details =====");
        // System.out.println("Message Id" + messagesIds.get(i) );
        // System.out.println("Recipient: " + recipientNumber.get(i));
        //System.out.println("Messsages: " + messages.get(i));
        //System.out.println("Message Hash: " + msgHash.get(i));
        //}
    } // close sendingMessage()

    public void storeMessage(String messageID, String recipient, String messageText, String messageHash) {
        try {
            FileWriter writer = new FileWriter("message.json");

            String jsonMessage = "{\n"
                    + "\"Message ID\": \"" + messageID + "\",\n"
                    + "\"Recipient\": \"" + recipient + "\",\n"
                    + "\"Message\": \"" + messageText + "\",\n"
                    + "\"Message Hash\": \"" + messageHash + "\"\n"
                    + "}\n";

            storedMessages.add(jsonMessage);

            writer.write("[\n");
            for (int i = 0; i < storedMessages.size(); i++) {
                writer.write(storedMessages.get(i));

                if (i < storedMessages.size() - 1) {
                    writer.write(",\n");
                }
            }
            writer.write("\n]");
            writer.close();

        } catch (IOException e) {
            System.out.println("Error string message");
        }
    }

    public int returnTotalMesssages() {
        return numMessageSent;

    }

    public String createMessageHash(String messageID,
            int messageNumber,
            String messageText) {

        String firstTwoNumbers = messageID.substring(0, 2);
        String trimmedMessage = messageText.trim();
        String[] words = trimmedMessage.split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        String hash = firstTwoNumbers
                + ":"
                + messageNumber
                + ":"
                + firstWord
                + lastWord;

        return hash.toUpperCase();
    }

    public String generateMessage() {

        String messageID;

        do {
            long number = 100000000L + random.nextLong(9000000000L);
            messageID = String.valueOf(number);

        } while (messagesIds.contains(messageID));

        messagesIds.add(messageID);

        return messageID;
    }

    public String checkRecipientCell(String cellphone) { // start of number method
        if (cellphone.matches("^\\+27\\d{9}$")
                || cellphone.matches("^0[0-9]{9}$")) {

            return "Valid number";

        } else {

            return "Invalid number. Pleaese enter a valid South African number";
        }

    }

    public String sentMessage(String messageID, String recipient, String messageText, String messageHash) {
        System.out.println("\nChoose what you want to do with this message!");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to send later");

        System.out.println("Enter your choice");
        int choice = input.nextInt();

        switch (choice) {

            case 1 -> {
                System.out.println("Message successfully sent");
                return "Sent";
            }
            case 2 -> {
                System.out.println("Press 0 to delete message");
                int deleteChoice = input.nextInt();

                if (deleteChoice == 0) {
                    System.out.println("Message deleted");

                    int lastIndex = messages.size() - 1;

                    messagesIds.remove(lastIndex);
                    recipientNumber.remove(lastIndex);
                    messages.remove(lastIndex);
                    msgHash.remove(lastIndex);

                    return "Disregard";
                } else {
                    System.out.print("Invalid option");
                    return "Disegarded";

                }
            }

            case 3 -> {

                storeMessage(messageID, recipient, messageText, messageHash);

                System.out.println("Message successfully stored");
                return "Stored";
            }

            default -> {
                System.out.print("Invalid option");
                return "Disregarded";

            }
        }
    }

    public String printMessages() {

        StringBuilder allMessages = new StringBuilder();

        System.out.print("\n ===== All Messages ====");

        for (int i = 0; i < messages.size(); i++) {
            allMessages.append("\nMessage Number: ").append(i + 1);
            allMessages.append("\nMessage ID: ").append(messagesIds.get(i));
            allMessages.append("\nRecipient: ").append(recipientNumber.get(i));
            allMessages.append("\nMessage: ").append(messages.get(i));
            allMessages.append("\nMessage Hash: ").append(msgHash.get(i));
            allMessages.append("\nStatus: ").append(messageStatus.get(i));

            System.out.println("\n===================");

            System.out.println("\n===== Messages details =====");
            System.out.println("Message Id" + messagesIds.get(i));
            System.out.println("Recipient: " + recipientNumber.get(i));
            System.out.println("Messsages: " + messages.get(i));
            System.out.println("Message Hash: " + msgHash.get(i));

        }

        return allMessages.toString();
    }

}
