/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part2;

/**
 *
 * @author Student
 */
public class Registration {
     String userName;
    String passWord;
    String cellPhone;
    String firstName;
    String lastName;

    public boolean checkUserName(String username) { // start of username method
        return username.contains("_") && username.length() <= 5;

    }  //end of username method

    public boolean checkPasswordComplexity(String password) { //start of password method
        return password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[a-z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^a-zA-Z0-9].*");
    }//end of checkPasswordComplexity method

    public boolean checkCellphoneNumber(String cellphone) { // start of number method
        return cellphone.matches("^\\+27\\d{9}$");
    }

    public String registerUser(String username, String password, String cellphone,
             String firstName, String lastName) { // start of registerUser
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more"
                    + "than five characters in lenght.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters"
                    + ",a capital letter, a number and a special character";

        }

        if (!checkCellphoneNumber(cellphone)) {
            return "Cell number is incorrectly formatted or does not contain an international code, please correct the number and"
                    + "try again.";
        }

        this.userName = username;
        this.passWord = password;
        this.cellPhone = cellphone;
        this.firstName = firstName;
        this.lastName = lastName;

        return "Registrtaion was a success";
    }

    public boolean registerStatus(String username, String password, String cellphone) {
        return checkUserName(username)
                && checkPasswordComplexity(password)
                && checkCellphoneNumber(cellphone);

    }//end of password method

}

