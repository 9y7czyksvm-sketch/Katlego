/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part2;

/**
 *
 * @author Student
 */
public class Login extends Registration {
    public boolean loginUser(String name, String password) {
     return userName != null            
             && passWord != null
             && userName.equals(name)
            && passWord.equals(password);

   }

    public String returnLoginStaus(boolean status) {

        if (status == true) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }

    }

}

