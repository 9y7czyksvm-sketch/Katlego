/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package part2;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Part2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    Login register = new Login();
    Registration reg = new Registration();
    Scanner scan = new Scanner(System.in);
        //Username input and checker

        System.out.println("=====Register=====");
        System.out.println("Enter first name");
        String firstName = scan.nextLine();

        System.out.println("Enter last name");
        String lastName = scan.nextLine();

        System.out.println("Please enter the username:");
        String name = scan.nextLine();

        System.out.println("Enter password");
        String password = scan.nextLine();

        System.out.println("Enter cellphone");
        String cellphone = scan.nextLine();

        System.out.println(register.registerUser(name, password, cellphone, firstName, lastName));

        System.out.println("n====== Login =====");
        //username checker
        System.out.println("enter username to login");
        String userName = scan.nextLine();

        System.out.println("enter password to log in");
        String passWord = scan.nextLine();

       boolean status = register.loginUser(userName, passWord);
      System.out.println(register.returnLoginStaus(status));

        if (status) {

            Message msg = new Message();

            System.out.print("Welcome to QuickChat.");

            int option;
            do {
                System.out.println("\n===== Select any of the options below ======");
                System.out.println("1. Send message");
                System.out.println("2. Show recently sent message");
                System.out.println("3. Quit");

                option = scan.nextInt();

                switch (option) {
                    case 1 ->
                        msg.sendingMessage();
                    case 2 ->
                        System.out.println("Coming soon.");
                    case 3 ->
                        System.out.println("Good bye!!");
                    default ->
                        System.out.println("Invalid option");

                }
            } while (option != 3);

        }

    }
}
    
  
