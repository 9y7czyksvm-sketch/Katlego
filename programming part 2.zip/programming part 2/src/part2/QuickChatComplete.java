import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Chat application combining the Part 1 registration/login requirements
 * with the Part 2 message workflow in one standalone Java source file.
 *
 * Compile: javac QuickChatComplete.java
 * Run:     java QuickChatComplete
 *
 * Messages selected for storage are written to message.json in the
 * current working directory. No external libraries are required.
 */
public class QuickChatComplete {
    private static final Scanner INPUT = new Scanner(System.in);
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final List<ChatMessage> MESSAGE_HISTORY = new ArrayList<>();
    private static final Path JSON_FILE = Path.of("message.json");

    public static void main(String[] args) {
        if (args.length > 0 && "--test".equals(args[0])) {
            runUnitTests();
            return;
        }
        System.out.println("======================================");
        System.out.println("       QUICKCHAT - ACCOUNT SETUP       ");
        System.out.println("======================================");

        Account account = registerAccount();
        if (account == null) {
            System.out.println("Registration was not completed. Goodbye.");
            return;
        }

        System.out.println("\n========== LOGIN ==========");
        boolean authenticated = login(account);
        if (!authenticated) {
            System.out.println("Too many unsuccessful login attempts. Goodbye.");
            return;
        }

        System.out.println("\nWelcome to QuickChat, " + account.firstName + "!");
        runMenu(account);
        System.out.println("Thank you for using QuickChat. Goodbye!");
    }


    /**
     * Lightweight unit tests that run without JUnit or any external library.
     * Run with: java QuickChatComplete --test
     */
    private static void runUnitTests() {
        int passed = 0;
        int failed = 0;
        System.out.println("========== QUICKCHAT UNIT TESTS ==========");

        passed += test("username accepts underscore within five characters",
                isValidUsername("ab_c"));
        passed += test("username accepts shortest underscore form",
                isValidUsername("_"));
        passed += test("username rejects missing underscore",
                !isValidUsername("abcde"));
        passed += test("username rejects more than five characters",
                !isValidUsername("ab_cde"));
        passed += test("username rejects null",
                !isValidUsername(null));

        passed += test("password accepts all required character types",
                isStrongPassword("Strong1!"));
        passed += test("password rejects fewer than eight characters",
                !isStrongPassword("Aa1!abc"));
        passed += test("password rejects missing uppercase",
                !isStrongPassword("strongpass1!"));
        passed += test("password rejects missing lowercase",
                !isStrongPassword("STRONGPASS1!"));
        passed += test("password rejects missing digit",
                !isStrongPassword("StrongPass!"));
        passed += test("password rejects missing special character",
                !isStrongPassword("StrongPass1"));
        passed += test("password rejects null",
                !isStrongPassword(null));

        passed += test("phone accepts +27 followed by nine digits",
                isValidSouthAfricanPhone("+27821234567"));
        passed += test("phone rejects local format without +27",
                !isValidSouthAfricanPhone("0821234567"));
        passed += test("phone rejects too few digits",
                !isValidSouthAfricanPhone("+2782123456"));
        passed += test("phone rejects letters",
                !isValidSouthAfricanPhone("+27821ABC567"));
        passed += test("phone rejects null",
                !isValidSouthAfricanPhone(null));

        passed += test("message hash uses first two ID digits, number and words",
                "12:1:HELLOWORLD".equals(createMessageHash("1234567890", 1, "Hello world")));
        passed += test("message hash handles repeated spaces",
                "98:3:GOODMORNING".equals(createMessageHash("9876543210", 3, "  good   morning  ")));
        passed += test("JSON escaping protects quotes and backslashes",
                "say \\\"hi\\\"".equals(jsonEscape("say \"hi\"")));

        failed = 20 - passed;
        System.out.println("------------------------------------------");
        System.out.println("Tests passed: " + passed);
        System.out.println("Tests failed: " + failed);
        if (failed > 0) {
            System.out.println("One or more tests failed. Review the implementation.");
            System.exit(1);
        }
        System.out.println("All unit tests passed.");
    }

    private static int test(String description, boolean condition) {
        if (condition) {
            System.out.println("[PASS] " + description);
            return 1;
        }
        System.out.println("[FAIL] " + description);
        return 0;
    }

    private static Account registerAccount() {
        String firstName = readNonBlank("Enter your first name: ");
        String lastName = readNonBlank("Enter your last name: ");

        String username;
        while (true) {
            username = readNonBlank("Create a username (must contain '_' and be at most 5 characters): ");
            if (isValidUsername(username)) {
                break;
            }
            System.out.println("Username is not correctly formatted. Include an underscore and use no more than five characters.");
        }

        String password;
        while (true) {
            password = readNonBlank("Create a password (8+ characters, uppercase, lowercase, digit and special character): ");
            if (isStrongPassword(password)) {
                break;
            }
            System.out.println("Password is not correctly formatted. Use at least 8 characters, an uppercase letter, a lowercase letter, a number and a special character.");
        }

        String phone;
        while (true) {
            phone = readNonBlank("Enter a South African cellphone number in international format (+27 followed by 9 digits): ");
            if (isValidSouthAfricanPhone(phone)) {
                break;
            }
            System.out.println("Cellphone number is incorrectly formatted. Example: +27821234567");
        }

        Account account = new Account(firstName, lastName, username, password, phone);
        System.out.println("\nRegistration was successful.");
        System.out.println("Username and cellphone number have been accepted.");
        return account;
    }

    // Part 1: username must contain an underscore and be no longer than 5 characters.
    static boolean isValidUsername(String username) {
        return username != null && username.length() <= 5 && username.contains("_");
    }

    // Part 1: password complexity checks.
    static boolean isStrongPassword(String password) {
        return password != null
                && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[a-z].*")
                && password.matches(".*\\d.*")
                && password.matches(".*[^a-zA-Z0-9].*");
    }

    // South African international format: +27 plus exactly nine digits.
    static boolean isValidSouthAfricanPhone(String phone) {
        return phone != null && phone.matches("^\\+27\\d{9}$");
    }

    private static boolean login(Account account) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            String username = readNonBlank("Username: ");
            String password = readNonBlank("Password: ");

            // Decision structure verifies both credentials.
            if (account.username.equals(username) && account.password.equals(password)) {
                System.out.println("Welcome " + account.firstName + " " + account.lastName
                        + ", it is great to see you again.");
                return true;
            }
            System.out.println("Username or password incorrect. Please try again."
                    + (attempt < 3 ? " Attempts remaining: " + (3 - attempt) : ""));
        }
        return false;
    }

    private static void runMenu(Account account) {
        int option;
        do {
            System.out.println("\n========== QUICKCHAT MENU ==========");
            System.out.println("1. Send message");
            System.out.println("2. Show sent and stored messages");
            System.out.println("3. Quit");
            option = readInt("Choose an option (1-3): ");

            switch (option) {
                case 1 -> addMessages();
                case 2 -> displayMessages();
                case 3 -> System.out.println("Closing the application...");
                default -> System.out.println("Invalid option. Please choose 1, 2 or 3.");
            }
        } while (option != 3);
    }

    private static void addMessages() {
        int requested;
        do {
            requested = readInt("How many messages would you like to compose? Enter a number greater than 0: ");
            if (requested <= 0) {
                System.out.println("Please enter a positive number.");
            }
        } while (requested <= 0);

        // The for-loop creates exactly the number of messages requested.
        for (int counter = 1; counter <= requested; counter++) {
            System.out.println("\n---------- Message " + counter + " of " + requested + " ----------");

            String recipient;
            do {
                recipient = readNonBlank("Recipient cellphone (+27 followed by 9 digits): ");
                if (!isValidSouthAfricanPhone(recipient)) {
                    System.out.println("Invalid recipient number. Example: +27821234567");
                }
            } while (!isValidSouthAfricanPhone(recipient));

            String text;
            do {
                text = readNonBlank("Enter your message (1-250 characters): ");
                if (text.length() > 250) {
                    System.out.println("Your message is too long. Keep it within 250 characters.");
                }
            } while (text.length() > 250);

            String id = generateMessageId();
            String hash = createMessageHash(id, counter, text);
            ChatMessage message = new ChatMessage(id, recipient, text, hash);

            System.out.println("\nMessage details");
            System.out.println("Message ID: " + message.id);
            System.out.println("Message number: " + counter);
            System.out.println("Recipient: " + message.recipient);
            System.out.println("Message: " + message.text);
            System.out.println("Message Hash: " + message.hash);

            int action;
            do {
                System.out.println("1. Send message");
                System.out.println("2. Disregard message");
                System.out.println("3. Store message as JSON");
                action = readInt("Choose an action (1-3): ");
                if (action < 1 || action > 3) {
                    System.out.println("Invalid option. Choose 1, 2 or 3.");
                }
            } while (action < 1 || action > 3);

            switch (action) {
                case 1 -> {
                    message.status = "Sent";
                    MESSAGE_HISTORY.add(message);
                    System.out.println("Message successfully sent.");
                }
                case 2 -> {
                    message.status = "Disregarded";
                    System.out.println("Message disregarded; it was not added to the message history.");
                }
                case 3 -> {
                    message.status = "Stored";
                    MESSAGE_HISTORY.add(message);
                    try {
                        writeMessagesAsJson();
                        System.out.println("Message successfully stored in " + JSON_FILE.toAbsolutePath());
                    } catch (IOException exception) {
                        MESSAGE_HISTORY.remove(message);
                        System.out.println("Could not save the JSON file: " + exception.getMessage());
                    }
                }
                default -> throw new IllegalStateException("Validated action became invalid.");
            }
        }
        System.out.println("\nMessages sent successfully: " + countSentMessages());
    }

    // Generates a unique 10-digit identifier and prevents duplicates in this run.
    private static String generateMessageId() {
        String candidate;
        do {
            candidate = Long.toString(1_000_000_000L + RANDOM.nextLong(9_000_000_000L));
        } while (containsMessageId(candidate));
        return candidate;
    }

    private static boolean containsMessageId(String candidate) {
        for (ChatMessage message : MESSAGE_HISTORY) {
            if (message.id.equals(candidate)) {
                return true;
            }
        }
        return false;
    }

    // Uses substring/string manipulation and the required loop counter.
    static String createMessageHash(String messageId, int messageNumber, String messageText) {
        String firstTwoDigits = messageId.substring(0, 2);
        String trimmed = messageText.trim();
        String[] words = trimmed.split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        return (firstTwoDigits + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    private static int countSentMessages() {
        int count = 0;
        for (ChatMessage message : MESSAGE_HISTORY) {
            if ("Sent".equals(message.status)) {
                count++;
            }
        }
        return count;
    }

    private static void displayMessages() {
        if (MESSAGE_HISTORY.isEmpty()) {
            System.out.println("There are no sent or stored messages yet.");
            return;
        }

        System.out.println("\n========== MESSAGE HISTORY ==========");
        for (int i = 0; i < MESSAGE_HISTORY.size(); i++) {
            ChatMessage message = MESSAGE_HISTORY.get(i);
            System.out.println("\nMessage " + (i + 1));
            System.out.println("Message ID: " + message.id);
            System.out.println("Recipient: " + message.recipient);
            System.out.println("Message: " + message.text);
            System.out.println("Message Hash: " + message.hash);
            System.out.println("Status: " + message.status);
        }
    }

    // Writes all currently stored messages as a valid JSON array.
    private static void writeMessagesAsJson() throws IOException {
        StringBuilder json = new StringBuilder("[\n");
        boolean first = true;
        for (ChatMessage message : MESSAGE_HISTORY) {
            if (!"Stored".equals(message.status)) {
                continue;
            }
            if (!first) {
                json.append(",\n");
            }
            json.append("  {\n")
                    .append("    \"Message ID\": \"").append(jsonEscape(message.id)).append("\",\n")
                    .append("    \"Recipient\": \"").append(jsonEscape(message.recipient)).append("\",\n")
                    .append("    \"Message\": \"").append(jsonEscape(message.text)).append("\",\n")
                    .append("    \"Message Hash\": \"").append(jsonEscape(message.hash)).append("\",\n")
                    .append("    \"Status\": \"").append(jsonEscape(message.status)).append("\"\n")
                    .append("  }");
            first = false;
        }
        json.append("\n]\n");
        Files.writeString(JSON_FILE, json.toString(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
    }

    private static String jsonEscape(String value) {
        StringBuilder escaped = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            switch (character) {
                case '"' -> escaped.append("\\\"");
                case '\\' -> escaped.append("\\\\");
                case '\b' -> escaped.append("\\b");
                case '\f' -> escaped.append("\\f");
                case '\n' -> escaped.append("\\n");
                case '\r' -> escaped.append("\\r");
                case '\t' -> escaped.append("\\t");
                default -> {
                    if (character < 0x20) {
                        escaped.append(String.format("\\u%04x", (int) character));
                    } else {
                        escaped.append(character);
                    }
                }
            }
        }
        return escaped.toString();
    }

    private static String readNonBlank(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();
            if (!value.isEmpty()) {
                return value;
            }
            System.out.println("This field cannot be blank.");
        }
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException exception) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    private static final class Account {
        private final String firstName;
        private final String lastName;
        private final String username;
        private final String password;
        private final String phone;

        private Account(String firstName, String lastName, String username, String password, String phone) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.phone = phone;
        }
    }

    private static final class ChatMessage {
        private final String id;
        private final String recipient;
        private final String text;
        private final String hash;
        private String status;

        private ChatMessage(String id, String recipient, String text, String hash) {
            this.id = id;
            this.recipient = recipient;
            this.text = text;
            this.hash = hash;
            this.status = "Pending";
        }
    }
}
